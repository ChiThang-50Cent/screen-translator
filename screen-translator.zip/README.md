# Screen Translator

[English](#english) | [Tiếng Việt](#tiếng-việt)

---

## English

### Description
A screen translation tool that helps translate text from screenshots and images.

### Features
- Quick screenshot translation
- Support multiple languages
- Easy-to-use interface

### Installation
1. Clone the repository
2. Install dependencies
3. Run the application

---

## Tiếng Việt

### Mô tả
Công cụ dịch màn hình giúp dịch văn bản từ ảnh chụp màn hình.

### Tính năng
- Dịch nhanh ảnh chụp màn hình
- Hỗ trợ nhiều ngôn ngữ
- Giao diện dễ sử dụng

### Cài đặt
1. Sao chép kho lưu trữ
2. Cài đặt các gói phụ thuộc
3. Chạy ứng dụng